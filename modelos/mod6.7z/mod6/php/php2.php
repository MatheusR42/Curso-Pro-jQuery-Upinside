<?php
print_r(json_encode($_GET));
