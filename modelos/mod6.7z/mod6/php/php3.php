<?php
sleep(2);
print_r($_POST);
