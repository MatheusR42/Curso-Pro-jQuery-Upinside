<?php
sleep(3);
print_r($_POST);
